public class DataTypeDemo {
    public static void main(String[] args) {
        int i = 100;
        float f = 10.5f;
        double d = 20.99;
        char c = 'A';
        boolean b = true;

        System.out.println("int: " + i);
        System.out.println("float: " + f);
        System.out.println("double: " + d);
        System.out.println("char: " + c);
        System.out.println("boolean: " + b);
    }
}
